import{ar as s}from"./q5iTckef.js";const r=s("/icon.svg");export{r as _};
