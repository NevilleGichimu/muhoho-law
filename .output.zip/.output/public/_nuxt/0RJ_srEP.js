import{ar as o,v as s}from"./q5iTckef.js";const r=o("/la-logo.png"),t=()=>s("color-mode").value;export{r as _,t as u};
