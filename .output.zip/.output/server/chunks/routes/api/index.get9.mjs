import { d as defineEventHandler, u as useRuntimeConfig, c as createError } from '../../nitro/nitro.mjs';
import { createClient } from '@supabase/supabase-js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const index_get = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const supabase = createClient(
    runtimeConfig.public.supabaseUrl,
    runtimeConfig.public.supabaseServiceRoleKey
  );
  if (!supabase) {
    throw createError({
      statusCode: 500,
      message: "Failed to initialize Supabase client."
    });
  }
  try {
    const { data, error } = await supabase.from("suppliers").select("*").order("created_at", { ascending: false });
    if (error) throw createError({ statusCode: 500, message: error.message });
    return { success: true, data };
  } catch (err) {
    console.error("Error fetching suppliers:", err);
    return { success: false, message: "Internal Server Error" };
  }
});

export { index_get as default };
//# sourceMappingURL=index.get9.mjs.map
