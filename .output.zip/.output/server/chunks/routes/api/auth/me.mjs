import { d as defineEventHandler, u as useRuntimeConfig, a as getHeader, c as createError } from '../../../nitro/nitro.mjs';
import { createClient } from '@supabase/supabase-js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const me = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const supabase = createClient(
    runtimeConfig.public.supabaseUrl,
    runtimeConfig.public.supabaseServiceRoleKey
  );
  const authHeader = getHeader(event, "authorization");
  if (!authHeader) {
    throw createError({ statusCode: 401, message: "Unauthorized" });
  }
  const token = authHeader.replace("Bearer ", "");
  const { data: user, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    throw createError({ statusCode: 401, message: "Invalid token" });
  }
  const { data: userData, error: userError } = await supabase.from("users").select("*").eq("id", user.id).single();
  if (userError) {
    throw createError({
      statusCode: 500,
      message: "Failed to retrieve user data"
    });
  }
  return { success: true, user: userData };
});

export { me as default };
//# sourceMappingURL=me.mjs.map
