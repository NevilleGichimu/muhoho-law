import { d as defineEventHandler, u as useRuntimeConfig, c as createError } from '../../../nitro/nitro.mjs';
import { createClient } from '@supabase/supabase-js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const counts_get = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const supabase = createClient(
    runtimeConfig.public.supabaseUrl,
    runtimeConfig.public.supabaseServiceRoleKey
  );
  if (!supabase) {
    throw createError({
      statusCode: 500,
      message: "Failed to initialize Supabase client."
    });
  }
  try {
    const { count: employeesCount, error: employeesError } = await supabase.from("employees").select("*", { count: "exact", head: true });
    const { count: suppliersCount, error: suppliersError } = await supabase.from("suppliers").select("*", { count: "exact", head: true });
    const { count: inventoryCount, error: inventoryError } = await supabase.from("inventory").select("*", { count: "exact", head: true });
    const { count: productsCount, error: productsError } = await supabase.from("products").select("*", { count: "exact", head: true });
    if (employeesError || suppliersError || productsError || inventoryError) {
      throw createError({
        statusCode: 500,
        message: "Error fetching counts."
      });
    }
    return {
      success: true,
      data: {
        employees: employeesCount,
        suppliers: suppliersCount,
        inventory: inventoryCount,
        products: productsCount
      }
    };
  } catch (err) {
    console.error("Error fetching counts:", err);
    return {
      success: false,
      message: "Internal Server Error"
    };
  }
});

export { counts_get as default };
//# sourceMappingURL=counts.get.mjs.map
