import { d as defineEventHandler, u as useRuntimeConfig, g as getQuery, c as createError } from '../../nitro/nitro.mjs';
import { createClient } from '@supabase/supabase-js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@iconify/utils';
import 'consola';

const index_get = defineEventHandler(async (event) => {
  const runtimeConfig = useRuntimeConfig();
  const supabase = createClient(
    runtimeConfig.public.supabaseUrl,
    runtimeConfig.public.supabaseServiceRoleKey
  );
  const { id } = getQuery(event);
  if (!id) {
    throw createError({ statusCode: 400, message: "Missing user ID" });
  }
  try {
    const { data: profile, error } = await supabase.from("users").select("*").eq("id", id).single();
    return { success: true, user: profile };
  } catch (err) {
    console.error("Error fetching profile:", err);
    return { success: false, message: "Failed to fetch user profile" };
  }
});

export { index_get as default };
//# sourceMappingURL=index.get7.mjs.map
